# GitHub Deployment Guide

This guide provides step-by-step instructions for deploying the PDF Payload Injector project to GitHub.

## Prerequisites

- GitHub account
- Git installed on your local machine
- SSH or HTTPS access to GitHub

## Step 1: Initialize Git Repository

```bash
# Initialize git in the project directory
git init

# Add all files
git add .

# Check status
git status
```

## Step 2: Create Initial Commit

```bash
# Create initial commit
git commit -m "Initial commit: PDF Payload Injector v1.0.0

- Complete PDF security testing tool
- 9 known CVE vulnerabilities
- Multi-platform payload support
- Comprehensive documentation
- Interactive and CLI interfaces
- Educational and authorized use only"
```

## Step 3: Create GitHub Repository

### Option A: Using GitHub CLI

```bash
# Install GitHub CLI (if not installed)
# On Ubuntu/Debian:
sudo apt install gh

# Login to GitHub
gh auth login

# Create repository
gh repo create pdf-payload-injector \
  --public \
  --description "Educational PDF security testing tool for authorized vulnerability research" \
  --source=. \
  --remote=origin \
  --push
```

### Option B: Manual GitHub Creation

1. Go to GitHub website
2. Click "+" → "New repository"
3. Fill in repository details:
   - Repository name: `pdf-payload-injector`
   - Description: `Educational PDF security testing tool for authorized vulnerability research`
   - Public/Private: Choose based on your preference
   - Initialize with: Leave blank (we'll push existing code)
4. Click "Create repository"
5. Copy the repository URL

## Step 4: Connect to Remote Repository

```bash
# Add remote repository (replace with your URL)
git remote add origin https://github.com/YOUR_USERNAME/pdf-payload-injector.git

# Verify remote
git remote -v

# Push to GitHub
git branch -M main
git push -u origin main
```

## Step 5: Configure Repository Settings

### Repository Settings

1. Go to repository Settings → General
2. Configure:
   - **Repository Name**: pdf-payload-injector
   - **Description**: Educational PDF security testing tool for authorized vulnerability research
   - **Website**: (optional)
   - **Topics**: pdf-security, cybersecurity, vulnerability-research, educational, penetration-testing
   - **Visibility**: Public/Private

### Topics (Labels)
Add these topics to improve discoverability:
- pdf-security
- cybersecurity
- vulnerability-research
- educational
- penetration-testing
- cve
- exploit
- pdf-analysis

## Step 6: Configure GitHub Features

### Branch Protection

1. Go to Settings → Branches
2. Click "Add branch protection rule"
3. Configure:
   - Branch name pattern: `main`
   - ✅ Require pull request reviews before merging
   - ✅ Require status checks to pass before merging
   - ✅ Require branches to be up to date before merging
   - Click "Create"

### Issues

1. Go to Settings → General → Features
2. Enable Issues (if not already enabled)
3. Configure issue templates in `.github/ISSUE_TEMPLATE/`

### Discussions

1. Go to Settings → General → Features
2. Enable Discussions for community interaction

### Actions

1. Go to Settings → Actions → General
2. Configure:
   - ✅ Allow all actions and reusable workflows
   - ✅ Allow GitHub Actions to create and approve pull requests

### Security

1. Go to Settings → Security → Code security and analysis
2. Enable:
   - ✅ Dependabot alerts
   - ✅ Dependabot security updates
   - ✅ Code scanning alerts (CodeQL)

### Dependency Graph

1. Go to Settings → Security → Dependency graph
2. Enable Dependency graph

## Step 7: Create Release

### Using GitHub Web Interface

1. Go to repository
2. Click "Releases" → "Create a new release"
3. Fill in:
   - Tag version: `v1.0.0`
   - Target: `main`
   - Release title: `PDF Payload Injector v1.0.0`
   - Description:
   ```
   ## PDF Payload Injector v1.0.0

   Initial release of the educational PDF security testing tool.

   ### Features
   - 9 known CVE vulnerabilities
   - Multi-platform payload support (Windows, Linux, macOS)
   - Multiple injection methods (JavaScript, Launch, Attachment)
   - Interactive and CLI interfaces
   - PDF analysis and security assessment
   - Built-in CVE and Exploit-DB databases

   ### Documentation
   - Comprehensive README
   - 26 usage examples
   - Legal disclaimer and ethical guidelines
   - Testing guide for educational purposes

   ### Installation
   ```bash
   git clone https://github.com/YOUR_USERNAME/pdf-payload-injector.git
   cd pdf-payload-injector
   pip install -r pdf_payload_injector/requirements.txt
   ```

   ### Important
   ⚠️ This tool is for educational and authorized security testing only.
   Use only on systems you own or have explicit permission to test.
   ```
4. Click "Publish release"

### Using GitHub CLI

```bash
# Create release
gh release create v1.0.0 \
  --title "PDF Payload Injector v1.0.0" \
  --notes "Initial release of the educational PDF security testing tool."
```

## Step 8: Configure GitHub Pages (Optional)

If you want to host documentation on GitHub Pages:

1. Go to Settings → Pages
2. Source: Deploy from a branch
3. Branch: `main`
4. Folder: `/docs` or `/` (root)
5. Click "Save"

## Step 9: Verify Deployment

### Check All Features

```bash
# Verify repository is accessible
git remote -v
git fetch origin

# Check branches
git branch -a

# Check tags
git tag
```

### Verify on GitHub

1. Visit your repository
2. Check all files are present
3. Verify README is displayed correctly
4. Check Actions are running
4. Verify release is published
5. Check all documentation is accessible

## Step 10: Post-Deployment Tasks

### Update README Links

If needed, update links in documentation to point to your repository:

```bash
# Update repository URLs
sed -i 's|https://github.com/yourusername/pdf-payload-injector|https://github.com/YOUR_USERNAME/pdf-payload-injector|g' README.md
sed -i 's|https://github.com/yourusername/pdf-payload-injector|https://github.com/YOUR_USERNAME/pdf-payload-injector|g' pdf_payload_injector/README.md
```

### Add Badges (Optional)

Add badges to your README.md:

```markdown
![GitHub Stars](https://img.shields.io/github/stars/YOUR_USERNAME/pdf-payload-injector)
![GitHub Forks](https://img.shields.io/github/forks/YOUR_USERNAME/pdf-payload-injector)
![GitHub Issues](https://img.shields.io/github/issues/YOUR_USERNAME/pdf-payload-injector)
![GitHub License](https://img.shields.io/github/license/YOUR_USERNAME/pdf-payload-injector)
```

### Setup Dependabot

Create `.github/dependabot.yml`:

```yaml
version: 2
updates:
  - package-ecosystem: "pip"
    directory: "/"
    schedule:
      interval: "weekly"
    open-pull-requests-limit: 10
```

### Setup Labels

Create custom labels for better issue management:
- `bug`
- `enhancement`
- `documentation`
- `security`
- `good first issue`
- `help wanted`
- `wontfix`

## Step 11: Community Engagement

### Create Discussion Topics

1. Go to Discussions tab
2. Create categories:
   - Announcements
   - General
   - Ideas
   - Q&A
   - Security

3. Create welcome post:
   ```
   Welcome to PDF Payload Injector! 👋

   This is an educational tool for PDF security testing and vulnerability research.
   
   ## Getting Started
   - Read the [README](README.md)
   - Check [Usage Examples](pdf_payload_injector/USAGE_EXAMPLES.md)
   - Review [Legal Disclaimer](pdf_payload_injector/LEGAL_DISCLAIMER.md)
   
   ## Community Guidelines
   - Be respectful and inclusive
   - Educational discussions only
   - No malicious use discussions
   - Follow [Code of Conduct](CODE_OF_CONDUCT.md)
   
   Ask questions, share ideas, and contribute responsibly!
   ```

### Setup Wiki (Optional)

Create a wiki for additional documentation:
- Installation guides
- Troubleshooting tips
- Advanced tutorials
- FAQ

## Step 12: Monitoring and Maintenance

### Watch Repository

1. Go to repository
2. Click "Watch" → "Custom"
3. Select:
   - ✅ Participating and @mentions
   - ✅ Watch
4. Click "Apply"

### Setup Notifications

Configure email preferences for:
- Issues
- Pull requests
- Releases
- Security alerts

### Regular Tasks

- Review and merge pull requests
- Respond to issues
- Update documentation
- Release new versions
- Monitor security alerts

## Step 13: Promotion (Optional)

### Share on Social Media

- Twitter/X
- LinkedIn
- Reddit (r/netsec, r/AskNetsec)
- Security forums

### Submit to Directories

- Awesome Security Tools
- GitHub Trending
- Security tool directories

## Troubleshooting

### Common Issues

**Push fails with authentication error:**
```bash
# Configure git credentials
git config --global user.name "Your Name"
git config --global user.email "your.email@example.com"

# Or use SSH instead of HTTPS
git remote set-url origin git@github.com:YOUR_USERNAME/pdf-payload-injector.git
```

**Large files not pushing:**
```bash
# Check file size limit
git rev-list --objects --all | git cat-file --batch-check='%(objecttype) %(objectname) %(objectsize) %(rest)' | awk '/^blob/ {print substr($0,6)}' | sort -n --key=2 | tail -n 10

# Consider using Git LFS for large files
```

**Actions not running:**
```bash
# Check workflow syntax
# Visit Actions tab to see error logs
# Ensure workflows are in .github/workflows/
```

## Security Checklist

- [ ] Repository visibility set correctly
- [ ] No sensitive information in code
- [ ] API keys/credentials removed
- [ ] Security policy configured
- [ ] Branch protection enabled
- [ ] Dependabot enabled
- [ ] Code scanning enabled
- [ ] Two-factor authentication enabled
- [ ] GitHub Actions security settings configured

## Next Steps

After successful deployment:

1. **Monitor** the repository regularly
2. **Respond** to issues and discussions
3. **Maintain** the codebase
4. **Update** dependencies
5. **Release** new versions
6. **Engage** with the community
7. **Document** changes
8. **Review** security updates

---

## Summary

Your PDF Payload Injector repository is now ready on GitHub! 

**Next Actions:**
1. Verify all files are present
2. Test Actions workflows
3. Create first release
4. Share with the community
5. Monitor for issues

**Remember:** This is an educational tool. Always emphasize authorized use only and comply with legal requirements.

---

**Need Help?**
- GitHub Documentation: https://docs.github.com
- GitHub Support: https://support.github.com
- Create an issue in the repository